DEIVAANAI INTERIOR — FREE STATIC WEBSITE

Files:
- index.html
- images/ (your uploaded project photos)

How to use:
1. Open index.html in a browser to preview the site.
2. Upload the whole folder to a free static hosting service such as GitHub Pages, Netlify, or Cloudflare Pages.
3. The WhatsApp and phone buttons already use +91 88835 26014.
4. Location: Nagercoil, Kanyakumari District, Tamil Nadu.

Business name used: Deivaanai Interior
